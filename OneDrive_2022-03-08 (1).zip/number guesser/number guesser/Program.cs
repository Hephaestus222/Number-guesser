﻿using System;

namespace number_guesser
{
    class Program
    {
        
        static void Main(string[] args)
        {
            bool Finished = false;
            Random rnd = new Random();
            int numbertoguess = rnd.Next(1, 10);
            int count = 0;
            while (Finished != true)
            {
                Console.Write("Guess a number: ");
                int guess = Convert.ToInt32(Console.ReadLine());
                if (guess > numbertoguess)
                {
                    Console.WriteLine("Answer is lower!");
                }
                else if (guess < numbertoguess)
                {
                    Console.WriteLine("Answer is higher!");
                }
                else
                {
                    Console.WriteLine("Correct!");
                    Finished = true;
                    count = 0;
                }
                count = count + 1;
                if (count == 3)
                {
                    Finished = true;
                }
            }
            if (count == 3)
            {
                Console.WriteLine("too many guesses");
            }
        }
    }
}
